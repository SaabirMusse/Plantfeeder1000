﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar;

namespace Plsntfeeder

{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        // Starting moisture level for each plant
        int plant1 = 100;
        int plant2 = 95;
        int plant3 = 90;
        int plant4 = 85;
        int plant5 = 80;
        int plant6 = 75;
        int plant7 = 98;
        int plant8 = 93;
        int plant9 = 87;
        int plant10 = 83;



        int count = 0;
        // getReading is function that get values from data.txt and returns it, we use this later Inerder to chanage value of each plant
        public string getReadings(int fieldNo, int recordNumber)
        {
            int count = 0;

            using (StreamReader file = new StreamReader(@"data.txt"))
            {
                string[] values = new string[20];
                string line;

                while (count <= recordNumber && !file.EndOfStream)
                {
                    line = file.ReadLine();
                    values = line.Split(',');
                    count++;
                }

                return values[fieldNo];
            }
        }


        // timerl Tick, every second the value of each plant is being decreased by value retrived by getReadings funcution making value of plant go down
        private void timer1_Tick(object sender, EventArgs e)
        {
            plant1 = plant1 - int.Parse(getReadings(0, count));
            plant2 = plant2 - int.Parse(getReadings(1, count));
            plant3 = plant3 - int.Parse(getReadings(2, count));
            plant4 = plant4 - int.Parse(getReadings(3, count));
            plant5 = plant5 - int.Parse(getReadings(4, count));
            plant6 = plant6 - int.Parse(getReadings(5, count));
            plant7 = plant7 - int.Parse(getReadings(6, count));
            plant8 = plant8 - int.Parse(getReadings(7, count));
            plant9 = plant9 - int.Parse(getReadings(8, count));
            plant10 = plant10 - int.Parse(getReadings(9, count));

            count++;

            // Moisture level for each plant is being added to chart1.Series["mositureLevels"), so we can see it on the chart
            chart1.Series["mositureLevels"].Points.Clear();
            chart1.ChartAreas[0].AxisY.Minimum = 0;
            chart1.ChartAreas[0].AxisY.Maximum = 100;

            chart1.Series["mositureLevels"].Points.AddXY("Plant1 ", plant1);

            chart1.Series["mositureLevels"].Points.AddXY("Plant2 ", plant2);

            chart1.Series["mositureLevels"].Points.AddXY("Plant3 ", plant3);

            chart1.Series["mositureLevels"].Points.AddXY("Plant4 ", plant4);

            chart1.Series["mositureLevels"].Points.AddXY("Plant5 ", plant5);

            chart1.Series["mositureLevels"].Points.AddXY("Plant6 ", plant6);

            chart1.Series["mositureLevels"].Points.AddXY("Plant7 ", plant7);

            chart1.Series["mositureLevels"].Points.AddXY("Plant8 ", plant8);

            chart1.Series["mositureLevels"].Points.AddXY("Plant9 ", plant9);

            chart1.Series["mositureLevels"].Points.AddXY("Plant10 ", plant10);


            // Plant alert so when water level goes below 40 alert is sent out and indicator change colour to red

            if (plant1 < 40)
            {
                label1.Text = ("Plant 1 needs watering");
                indicator1.Image = picRed.Image;
            }
            else
            {
                label1.Text = ("");
                indicator1.Image = picGreen.Image;

            }

            if (plant2 < 40)
            {
                label2.Text = ("Plant 2 needs watering");
                indicator2.Image = picRed.Image;
            }
            else
            {
                label2.Text = ("");
                indicator2.Image = picGreen.Image;
            }

            if (plant3 < 40)
            {
                label3.Text = ("Plant 3 needs watering");
                indicator3.Image = picRed.Image;
            }
            else
            {
                label3.Text = ("");
                indicator3.Image = picGreen.Image;
            }

            if (plant4 < 40)
            {
                label4.Text = ("Plant 4 needs watering");
                indicator4.Image = picRed.Image;
            }
            else
            {
                label4.Text = ("");
                indicator4.Image = picGreen.Image;
            }

            if (plant5 < 40)
            {
                label5.Text = ("Plant 5 needs watering");
                indicator5.Image = picRed.Image;
            }
            else
            {
                label5.Text = ("");
                indicator5.Image = picGreen.Image;
            }

            if (plant6 < 40)
            {
                label6.Text = ("Plant 6 needs watering");
                indicator6.Image = picRed.Image;
            }
            else
            {
                label6.Text = ("");
                indicator6.Image = picGreen.Image;
            }

            if (plant7 < 40)
            {
                label7.Text = ("Plant 7 needs watering");
                indicator7.Image = picRed.Image;
            }
            else
            {
                label7.Text = ("");
                indicator7.Image = picGreen.Image;
            }

            if (plant8 < 40)
            {
                label8.Text = ("Plant 8 needs watering");
                indicator8.Image = picRed.Image;
            }
            else
            {
                label8.Text = ("");
                indicator8.Image = picGreen.Image;
            }

            if (plant9 < 40)
            {
                label9.Text = ("Plant 9 needs watering");
                indicator9.Image = picRed.Image;
            }
            else
            {
                label9.Text = ("");
                indicator9.Image = picGreen.Image;
            }
            if (plant10 < 40)
            {
                label10.Text = ("Plant 10 needs watering");
                indicator10.Image = picRed.Image;
            }
            else
            {
                label10.Text = ("");
                indicator10.Image = picGreen.Image;
            }


            // Plant alert for each plant so when it goes greater or equal value of 100 an alert is sent out for that plant to: "Stop watering plant"

            if (plant1 <= 100 )
            {

            }
            else
            {
                label1.Text = ("Stop watering plant 1");

            }

            if (plant2 <= 100)
            {

            }
            else
            {
                label2.Text = ("Stop watering plant 2");

            }

            if (plant3 <= 100)
            {
     

            }
            else
            {
                label3.Text = ("Stop watering plant 3");

            }

            if (plant4 <= 100)
            {


            }
            else
            {
                label4.Text = ("Stop watering plant 4");

            }

            if (plant5 <= 100)
            {
       

            }
            else
            {
                label5.Text = ("Stop watering plant ");

            }

            if (plant6 <= 100)
            {
    
            }
            else
            {
                label6.Text = ("Stop watering plant 6");
            }

            if (plant7 <= 100)
            {
        
            }
            else
            {
                label7.Text = ("Stop watering plant 7");

            }

            if (plant8 <= 100)
            {
        

            }
            else
            {
                label8.Text = ("Stop watering plant 8");

            }

            if (plant9 <=100)
            {
             

            }
            else
            {
                label9.Text = label8.Text = ("Stop watering plant 9");

            }

            if (plant10 <= 100)
            {
                

            }
            else
            {
                label10.Text = ("Stop watering plant ");

            }






        }
        // Increase value of plant mostuire level when water buttons are pressed
        private void button1_Click(object sender, EventArgs e)
        {
            plant1 = plant1 + 5;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            plant2 = plant2 + 5;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            plant3 = plant3 + 5;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            plant4 = plant4 + 5;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            plant5 = plant5 + 5;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            plant6 = plant6 + 5;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            plant7 = plant7 + 5;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            plant8 = plant8 + 5;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            plant9 = plant9 + 5;
        }

        private void button10_Click(object sender, EventArgs e)
        {
            plant10 = plant10 + 5;
        }
    }      
}
